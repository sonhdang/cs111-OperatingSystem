//NAME: Son Dang
//EMAIL: sonhdang@ucla.edu
//ID: 105215636

#include <getopt.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

long long counter = 0;      // Global variable so other threads can access

void add(long long *pointer, long long value)
{
    long long sum = *pointer + value;
    *pointer = sum;
}

void* add_thread(void* arg)
{
    long long *num_iterations = (long long *) arg;
    for (int i = 0; i < *num_iterations; i++)
    {
        add(&counter, 1);
        add(&counter, -1);
    }
    pthread_exit(0);
}

int main(int argc, char *argv[])
{
    struct timespec start_time;
    struct timespec end_time;
    int c;
    int num_threads = 1;         // Number of threads
    int num_iterations = 1;      // Number of iterations

    while(1)
    {
        static struct option long_options[] =
        {
            {"threads", optional_argument, NULL, 't'},
            {"iterations", optional_argument, NULL, 'i'},
            {0, 0, 0, 0}
        };

        int option_index = 0;
        c = getopt_long_only(argc, argv, "", long_options, &option_index);

        int sscanf_ret = -1;

        if (c == -1)
            break;
        
        switch (c)
        {
            case 't':   // THREAD
                sscanf_ret = sscanf(optarg, "%d", &num_threads);
                if( sscanf_ret == EOF)
                {
                    printf("error, NOTHING WAS INPUT");
                } 
                else if (sscanf_ret == 0)
                {
                    printf("input needs to be an integer\n");
                }
                break;
            case 'i':   //ITERATION
                sscanf_ret = sscanf(optarg, "%d", &num_iterations);
                if( sscanf_ret == EOF)
                {
                    printf("error, NOTHING WAS INPUT");
                } 
                else if (sscanf_ret == 0)
                {
                    printf("input needs to be an integer\n");
                }
                break;
        }
    }

    long long counter = 0;
    pthread_t threads[num_threads];
    int thread_ret;

    int clock_ret = clock_gettime(CLOCK_MONOTONIC, &start_time);

    for (int i = 0; i <= num_threads; i++)
    {
        thread_ret = pthread_create(&threads[i], NULL, add_thread, (void *)&num_iterations);
        if (thread_ret)
        {
            printf("ERROR: pthread_create() returns %d\n", thread_ret);
            exit(-1);
        }
    }

    //pthread_join(tid, NULL);
    clock_ret = clock_gettime(CLOCK_MONOTONIC, &end_time);

    long num_operations = num_threads * num_iterations * 2;
    long runtime = end_time.tv_nsec - start_time.tv_nsec;
    int average_time = runtime / num_operations;
    printf("add_none,%d,%d,%ld,%ld,%d,%lld\n", num_threads, num_iterations, 
            num_operations, runtime, average_time, counter);
    printf("start second: %ld, end second: %ld\n", start_time.tv_sec, end_time.tv_sec);
    printf("start nano second: %ld, end nano second: %ld\n", start_time.tv_nsec, end_time.tv_nsec);
    exit(EXIT_SUCCESS);
}